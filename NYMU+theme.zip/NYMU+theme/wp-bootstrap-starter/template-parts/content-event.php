<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WP_Bootstrap_Starter
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="container single-section">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <div class="single-photo">
                    <img src="<?php the_post_thumbnail_url();?>" alt="">
                </div>
            </div>

            <div class="col-lg-6 col-md-12">
                <div class="col-12 single-event-title">
                    <div class="row">
                        <div class="event-date col-2">
                            <?php echo date("m",strtotime(get_post_meta($post->ID, 'event_start_date', true))); ?>月<br>
                            <?php echo date("d",strtotime(get_post_meta($post->ID, 'event_start_date', true))); ?>日
                        </div>
                        <div class="col-6">
                            <h2>
                                <?php echo get_the_title();?>
                            </h2>
                            
                        </div>
                    </div>
                </div>
                
                <div class="event-content">
                    <div class="row">
                        <div class="event-info col-12">
                            <p>時間：<?php echo date("m/d",strtotime(get_post_meta($post->ID, 'event_start_date', true))); ?>
                            <?php echo date("H:i a",strtotime(get_post_meta($post->ID, 'event_start_date', true))); ?>
                            </p>
                            <p>舉辦單位：<?php echo get_post_meta($post->ID, 'event_holder', true);?></p>
                            <p>地點：<?php echo get_post_meta($post->ID, 'event_place', true);?></p>
                        </div>
                    </div>
                    <div class="event-description">
                        <p>活動詳情：<br><?php echo get_post_meta($post->ID, 'event_description', true);?></p>
                    </div>
                    </div>
                </div>
            </div>
        <div>
    </div>
</article><!-- #post-## -->
