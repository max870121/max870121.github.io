<?php /* Template Name:Front Page*/ ?>
<?php
get_header();
    ?>
<!-- Slide show -->
<div class=" row">
    <div class="col-xl-12">
        <div id="carouselExampleIndicators" class="carousel slide front-slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="carousel-caption slide-caption">
                        <h1>NYMU+</h1>
                        <p>專為陽明人所做的平台</p>
                        <a href="#content" class="page-scroller"><i class="fa fa-fw fa-angle-down" style="color: white;"></i></a>
                    </div>
                    <img class="d-block w-100" src="<?php echo get_template_directory_uri(); ?>/inc/assets/img/mountain.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <div class="carousel-caption slide-caption">
                    <h1>NYMU+</h1>
                    <p>專為陽明人所做的平台</p>
                    <a href="#content" class="page-scroller"><i class="fa fa-fw fa-angle-down"></i></a>
                    </div>
                    <img class="d-block w-100" src="<?php echo get_template_directory_uri(); ?>/inc/assets/img/mountain.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <div class="carousel-caption slide-caption">
                    <h1>NYMU+</h1>
                    <p>專為陽明人所做的平台</p>
                    <a href="#content" class="page-scroller"><i class="fa fa-fw fa-angle-down"></i></a>
                    </div>
                    <img class="d-block w-100" src="<?php echo get_template_directory_uri(); ?>/inc/assets/img/mountain.jpg" alt="">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</div>

<!-- front-page event section -->
<div id="content" class="fluid-container">
    <div class="front-section" id="event">
        <div class="container">
            <div class="row section-header justify-content-center">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3" style="font-family:'Noto Sans TC';">
                    <div class="page-title">
                        <h1>精彩活動</h1>
                            <p>蒐羅所有社團活動，參加活動不掉線</p>
                        <div class="line"></div>
                    </div>
                </div>
            </div>
        <?php
            $args=array(
               'post_type'=>'Event',
               'meta_key'     => 'event_start_date',
               'orderby'   => 'meta_value',
                'order' => 'ASC',
               'meta_query' => array( // WordPress has all the results, now, return only the events after today's date
                        'key' => 'event_start_date', // Check the start date field
                        'value' => date("Y-m-d"),
                        'compare' => ">=", // 
                        'type' => 'DATE' // Let WordPress know we're working with date
                    ),
               'posts_per_page'=>4);
            $my_query=new WP_Query($args);
            if($my_query->have_posts()):
                $counter=0;
                ?>
                <div class="row">
                    <?php
                    while($my_query->have_posts()){
                        $my_query->the_post();?>
                            <div class="col-lg-3 col-md-6 col-xs-12 card outer-card">
                                <a href="<?php the_permalink();?>" style="height:100%">
                                    <div class="single-team card" style="height:100%">
                                        <div class="team-photo">
                                            <img src="<?php the_post_thumbnail_url();?>" alt="">
                                        </div>
                                        <div class="event-title">
                                            <h5>
                                                <?php
                                                    $title=the_title();
                                                    echo ($title);
                                                ?>
                                            </h5>
                                        </div>
                                        <div class="event-content">
                                            <p>日期：<?php echo substr(get_post_meta($post->ID, 'event_time', true),0,5); ?></p>
                                            <p>地點：<?php echo get_post_meta($post->ID, 'event_place', true);?></p>
                                            <p>舉辦單位：<?php echo get_post_meta($post->ID, 'event_holder', true);?></p>
                                        </div>
                                    </div>
                                    <div class="card-footer outer-card">
                                    </div>
                                </a>
                            </div>
                    <?php
                    }?>
                </div>
            <?php
            else:
                echo'<p>No content found</p>';
            endif;
            wp_reset_postdata();
        ?>
        </div>
    </div>

    <div class="front-section" id="food">
        <div class="container">
            <div class="row section-header justify-content-center">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3" style="font-family:'Noto Sans TC';">
                    <div class="page-title">
                        <h1>各式美食</h1>
                            <p>蒐羅陽明石牌附近美食、消夜飲料沒煩惱</p>
                        <div class="line"></div>
                    </div>
                </div>
            </div>
        <?php
            $args=array(
               'post_type'=>'Event',
               'meta_key'     => 'event_start_date',
               'orderby'   => 'meta_value',
                'order' => 'ASC',
               'meta_query' => array( // WordPress has all the results, now, return only the events after today's date
                        'key' => 'event_start_date', // Check the start date field
                        'value' => date("Y-m-d"),
                        'compare' => ">=", // 
                        'type' => 'DATE' // Let WordPress know we're working with date
                    ),
               'posts_per_page'=>4);
            $my_query=new WP_Query($args);
            if($my_query->have_posts()):
                $counter=0;
                ?>
                <div class="row">
                    <?php
                    while($my_query->have_posts()){
                        $my_query->the_post();?>
                            <div class="col-lg-3 col-md-6 col-xs-12 card outer-card">
                                <a href="<?php the_permalink();?>" style="height:100%">
                                    <div class="single-team card" style="height:100%">
                                        <div class="team-photo">
                                            <img src="<?php the_post_thumbnail_url();?>" alt="">
                                        </div>
                                        <div class="event-title">
                                            <h5>
                                                <?php
                                                    $title=the_title();
                                                    echo ($title);
                                                ?>
                                            </h5>
                                        </div>
                                        <div class="event-content">
                                            <p>日期：<?php echo substr(get_post_meta($post->ID, 'event_start_date', true),0,5); ?></p>
                                            <p>地點：<?php echo get_post_meta($post->ID, 'event_place', true);?></p>
                                            <p>舉辦單位：<?php echo get_post_meta($post->ID, 'event_holder', true);?></p>
                                        </div>
                                    </div>
                                    <div class="card-footer outer-card">
                                    </div>
                                </a>
                            </div>
                    <?php
                    }?>
                </div>
            <?php
            else:
                echo'<p>No content found</p>';
            endif;
            wp_reset_postdata();
        ?>
        </div>
    </div>


</div> <!-- container -->
<?php get_footer();
?>