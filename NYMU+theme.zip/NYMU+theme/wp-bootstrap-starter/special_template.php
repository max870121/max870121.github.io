<?php /* Template Name:Event */ ?>
<?php
get_header();
    ?>
<div class="container">
    <nav class="navbar navbar-light event-nav">
        <form class="form-inline">
            <button class="btn btn-outline-success" type="button">我的活動</button>
            <button class="btn btn-outline-primary" type="button">新增活動</button>
        </form>
    </nav>
    <div class="container event-section">
        <div class="row section-header">
            <div class="col-xs-12 col-sm-6 col-sm-offset-3" style="font-family:'Noto Sans TC';">
                    <h4>三天內活動</h4>
            </div>
        </div>
        <?php
            $nextweek=time() + (3 * 24 * 60 * 60);
            $args=array(
                'orderby'   => 'meta_value',
                'order' => 'ASC',
               'post_type'=>'Event',
               'meta_key'     => 'event_start_date',
               'meta_query' => array( // WordPress has all the results, now, return only the events after today's date
                        'key' => 'event_start_date', // Check the start date field
                        'value' => array(date("Y-m-d"),date("Y-m-d",$nextweek)),
                        'compare' => "BETWEEN", // 
                        'type' => 'DATE' // Let WordPress know we're working with date
                    ),
               'posts_per_page'=>10);
            $my_query=new WP_Query($args);
            if($my_query->have_posts()):
                $counter=0;
                ?>
                <div class="row">
                    <?php
                    while($my_query->have_posts()){
                        $my_query->the_post();?>
                            <div class="col-lg-3 col-md-6 col-xs-12 card outer-card">
                                <a href="<?php the_permalink();?>" style="height:100%">
                                    <div class="single-team card" style="height:100%">
                                        <div class="team-photo">
                                            <img src="<?php the_post_thumbnail_url();?>" alt="">
                                        </div>
                                        <div class="event-title">
                                            <h5>
                                                <?php
                                                    $title=the_title();
                                                    echo ($title);
                                                ?>
                                            </h5>
                                        </div>
                                        <div class="event-content">
                                            <p>日期：<?php echo substr(get_post_meta($post->ID, 'event_start_date', true),0,5); ?></p>
                                            <p>地點：<?php echo get_post_meta($post->ID, 'event_place', true);?></p>
                                            <p>舉辦單位：<?php echo get_post_meta($post->ID, 'event_holder', true);?></p>
                                        </div>
                                    </div>
                                    <div class="card-footer outer-card">
                                    </div>
                                </a>
                            </div>
                    <?php
                    }?>
                </div>
            <?php
            else:
                echo'<p>No content found</p>';
            endif;
            wp_reset_postdata();
        ?>
    </div>

    <div class="container event-section">
        <div class="row section-header">
            <div class="col-xs-12 col-sm-6 col-sm-offset-3">
                    <h4>未來活動</4>
            </div>
        </div>
        <?php
            $nextweek=time() + (3 * 24 * 60 * 60);
            $args=array(
                'orderby'   => 'meta_value',
                'order' => 'ASC',
               'post_type'=>'Event',
               'meta_key'     => 'event_start_date',
               'meta_query' => array( // WordPress has all the results, now, return only the events after today's date
                        'key' => 'event_start_date', // Check the start date field
                        'value' => date("Y-m-d",$nextweek),
                        'compare' => ">", // 
                        'type' => 'DATE' // Let WordPress know we're working with date
                    ),
               'posts_per_page'=>10);
            $my_query=new WP_Query($args);
            if($my_query->have_posts()):
                $counter=0;
                ?>
                <div class="row">
                    <?php
                    while($my_query->have_posts()){
                        $my_query->the_post();?>
                            <div class="col-lg-3 col-md-6 col-xs-12 card outer-card">
                                <a href="<?php the_permalink();?>" style="height:100%">
                                    <div class="single-team card" style="height:100%">
                                        <div class="team-photo">
                                            <img src="<?php the_post_thumbnail_url();?>" alt="">
                                        </div>
                                        <div class="event-title">
                                            <h5>
                                                <?php
                                                    $title=the_title();
                                                    echo ($title);
                                                ?>
                                            </h5>
                                        </div>
                                        <div class="event-content">
                                            <p>日期：<?php echo substr(get_post_meta($post->ID, 'event_start_date', true),0,5); ?></p>
                                            <p>地點：<?php echo get_post_meta($post->ID, 'event_place', true);?></p>
                                            <p>舉辦單位：<?php echo get_post_meta($post->ID, 'event_holder', true);?></p>
                                        </div>
                                    </div>
                                    <div class="card-footer outer-card">
                                    </div>
                                </a>
                            </div>
                    <?php
                    }?>
                </div>
            <?php
            else:
                echo'<p>No content found</p>';
            endif;
            wp_reset_postdata();
        ?>
    </div>

    <div class="container event-section">
        <div class="row section-header">
            <div class="col-xs-12 col-sm-6 col-sm-offset-3">
                    <h4>已結束活動</4>
            </div>
        </div>
        <?php
            $args=array(
                'orderby'   => 'meta_value',
                'order' => 'ASC',
               'post_type'=>'Event',
               'meta_key'     => 'event_start_date',
               'meta_query' => array( // WordPress has all the results, now, return only the events after today's date
                        'key' => 'event_start_date', // Check the start date field
                        'value' => date("Y-m-d"),
                        'compare' => "<", // 
                        'type' => 'DATE' // Let WordPress know we're working with date
                    ),
               'posts_per_page'=>10);
            $my_query=new WP_Query($args);
            if($my_query->have_posts()):
                $counter=0;
                ?>
                <div class="row">
                    <?php
                    while($my_query->have_posts()){
                        $my_query->the_post();?>
                            <div class="col-lg-3 col-md-6 col-xs-12 card outer-card">
                                <a href="<?php the_permalink();?>" style="height:100%">
                                    <div class="single-team card" style="height:100%">
                                        <div class="team-photo">
                                            <img src="<?php the_post_thumbnail_url();?>" alt="">
                                        </div>
                                        <div class="event-title">
                                            <h5>
                                                <?php
                                                    $title=the_title();
                                                    echo ($title);
                                                ?>
                                            </h5>
                                        </div>
                                        <div class="event-content">
                                            <!-- <p><?php echo date("m/d/Y", $nextweek)?></p> -->
                                            <p>日期：<?php echo substr(get_post_meta($post->ID, 'event_start_date', true),0,5); ?></p>
                                            <p>地點：<?php echo get_post_meta($post->ID, 'event_place', true);?></p>
                                            <p>舉辦單位：<?php echo get_post_meta($post->ID, 'event_holder', true);?></p>
                                        </div>
                                    </div>
                                    <div class="card-footer outer-card">
                                    </div>
                                </a>
                            </div>
                    <?php
                    }?>
                </div>
            <?php
            else:
                echo'<p>No content found</p>';
            endif;
            wp_reset_postdata();
        ?>
    </div>
</div> <!-- container -->
<?php get_footer();
?>